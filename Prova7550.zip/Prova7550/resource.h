//{{NO_DEPENDENCIES}}
// Arquivo de inclus�o gerado pelo Microsoft Visual C++.
// Usado por Prova7550.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_Prova7550TYPE               130
#define ID_WINDOW_MANAGER               131
#define IDD_DIALOG2                     312
#define IDC_EDIT1                       1002
#define IDC_EDIT2                       1003
#define IDC_EDIT3                       1004
#define IDC_EDIT4                       1005
#define IDC_EDIT5                       1006
#define ID_CONFIGURAR_ALTERARCORSOL     32771
#define ID_CONFIGURAR_ALTERARCORLUA     32772
#define ID_CONFIGURAR_ALTERARCORTERRA   32773
#define ID_CONFIGURAR_ALTERARRAIO       32774
#define ID_CONFIGURAR_ALTERARTIMER      32775
#define ID_CONFIGURAR_ALTERARORBITA     32776
#define ID_CONFIGURAR_MOSTRARORBITA     32777
#define ID_CONFIGURAR_MOSTRARTIMER      32778

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        313
#define _APS_NEXT_COMMAND_VALUE         32787
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
