// pch.cpp: arquivo de origem correspondente ao cabeçalho pré-compilado

#include "pch.h"

// Quando você estiver usando cabeçalhos pré-compilados, esse arquivo de origem será necessário para que a compilação seja bem-sucedida.
